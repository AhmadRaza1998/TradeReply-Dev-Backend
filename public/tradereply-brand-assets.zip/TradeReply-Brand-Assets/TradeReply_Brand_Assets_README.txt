# TradeReply Brand Assets Usage Guide

## 1. Overview:
Thank you for partnering with TradeReply! This folder contains official brand assets in various formats and configurations. Please follow the guidelines below to ensure proper usage.

## 2. Contents:
The assets provided include the following variations:

### Color Schemes:
- White only
- Black only
- White and cyan (main logo)
- Black and cyan

### Layouts:
- Logo with icon on the left side
- Logo and icon with tagline together
- Logo only
- Square version (icon only)

All assets are high-quality PNG files, including those with transparent backgrounds.

## 3. Brand Guidelines:
- **Authorization:** Explicit written authorization is required for the use of TradeReply brand assets.
- **Capitalization:** Always use a capital 'T' and 'R' when referencing TradeReply (e.g., "Log and analyze your trades with TradeReply").
- **Modification:** Do not modify, distort, recreate, redesign, or create variations or derivatives from the TradeReply brand assets.
- **Integration:** Do not incorporate TradeReply brand assets into your own product, service names, logos, social media handles, trademarks, or company names.
- **Affiliation:** Ensure that the use of TradeReply brand assets does not create confusion about our sponsorship, affiliation, or endorsement of your company, product, or services.
- **Ownership:** TradeReply brand assets are our exclusive property, and any goodwill generated from their use accrues to TradeReply.
- **Web Use:** When using TradeReply brand assets on a webpage, please include embedded hyperlinks to our homepage (https://www.tradereply.com).
- **Respectful Use:** TradeReply brand assets must be used respectfully and in accordance with our Terms of Service. Do not associate our brand assets with illicit or illegal activities, and avoid any use that could damage our products, services, reputation, or goodwill.

## 4. Usage Guidelines:
- **Do:** Use the assets for websites, presentations, or marketing materials related to TradeReply.
- **Do Not:** Alter the logos, icons, colors, or layouts (e.g., stretching, recoloring, or adding effects).
- **Do:** Maintain proper spacing around the logo (minimum spacing = 10% of the logo’s height).
- **Do Not:** Place the logo on busy or low-contrast backgrounds where it may be difficult to see.

## 5. File Formats:
All files are provided in PNG format for versatility and transparency. For vector files or other formats, please contact us at support@tradereply.com.

## 6. Brand Colors:
Our official brand colors are:
- **Cyan (Main Color):** #00adef
- **Black:** #000000
- **White:** #ffffff

Ensure that these colors are preserved when using our logos and assets.

## 7. Contact Information:
For questions about logo usage or to request additional file formats, reach out to us at support@tradereply.com.

**Thank you for helping maintain the integrity of the TradeReply brand!**
